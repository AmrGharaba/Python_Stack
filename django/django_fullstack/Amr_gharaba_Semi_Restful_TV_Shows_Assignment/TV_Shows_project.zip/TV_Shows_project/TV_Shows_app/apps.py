from django.apps import AppConfig


class TvShowsAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'TV_Shows_app'
